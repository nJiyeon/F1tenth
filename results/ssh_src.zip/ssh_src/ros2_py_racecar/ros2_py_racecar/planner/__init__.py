"""
If you want to create subdirectory,
create __init__.py file like you are looking at.

하위 디렉터리를 생성하려면 이와 같은 __init__.py 파일을 생성해주세요.
"""