# waypoint_logger
 Waypoint Logger ROS2
