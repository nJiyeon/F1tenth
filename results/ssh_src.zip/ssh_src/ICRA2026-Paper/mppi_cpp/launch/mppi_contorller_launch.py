#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    # 패키지 경로 가져오기
    pkg_share = FindPackageShare('mppi_controller_cpp').find('mppi_controller_cpp')
    
    # 기본 파라미터 파일 경로
    default_params_file = os.path.join(pkg_share, 'config', 'params.yaml')
    
    # Launch arguments
    params_file_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_file,
        description='Path to the parameters file'
    )
    
    visualize_arg = DeclareLaunchArgument(
        'visualize',
        default_value='true',
        description='Enable visualization'
    )
    
    # MPPI Controller Node
    mppi_controller_node = Node(
        package='mppi_controller_cpp',
        executable='mppi_controller_node',
        name='mppi_controller',
        output='screen',
        parameters=[LaunchConfiguration('params_file')],
        remappings=[
            # 필요시 토픽 이름 리매핑
            # ('/local_map', '/your_occupancy_topic'),
        ]
    )
    
    return LaunchDescription([
        params_file_arg,
        visualize_arg,
        mppi_controller_node
    ])
