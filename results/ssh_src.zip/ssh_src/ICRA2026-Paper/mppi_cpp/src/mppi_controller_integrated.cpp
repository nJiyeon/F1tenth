#include "mppi_controller_integrated.hpp"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cmath>

// ============================================================================
// Kinematic Bicycle Model Implementation
// ============================================================================

KinematicBicycleModel::KinematicBicycleModel(double wheelbase, double min_throttle,
                                             double max_throttle, double max_steer, double dt)
    : wheelbase_(wheelbase), min_throttle_(min_throttle), max_throttle_(max_throttle),
      max_steer_(max_steer), dt_(dt) {}

Eigen::Vector3d KinematicBicycleModel::predict_euler(const Eigen::Vector3d& state,
                                                      const Eigen::Vector2d& action) {
    double x = state(0);
    double y = state(1);
    double theta = state(2);
    double v = action(0);
    double delta = action(1);
    
    // Kinematic bicycle model equations
    double x_dot = v * std::cos(theta);
    double y_dot = v * std::sin(theta);
    double theta_dot = (v / wheelbase_) * std::tan(delta);
    
    // Euler integration
    Eigen::Vector3d next_state;
    next_state(0) = x + x_dot * dt_;
    next_state(1) = y + y_dot * dt_;
    next_state(2) = theta + theta_dot * dt_;
    
    return next_state;
}

// ============================================================================
// MPPI Controller Implementation
// ============================================================================

MPPIController::MPPIController() : Node("MPPI"), gen_(std::random_device{}()), dist_(0.0, 1.0) {
    // Initialize parameters
    initialize_parameters();
    
    // Initialize mean control
    u_mean_ << min_throttle_, 0.0;
    
    // Initialize dynamics model
    model_ = std::make_unique<KinematicBicycleModel>(
        wheelbase_, min_throttle_, max_throttle_, max_steer_, dt_);
    
    // Initialize cost map
    cost_map_.header.frame_id = vehicle_frame_;
    cost_map_.info.resolution = cost_map_res_;
    cost_map_.info.width = cost_map_width_;
    cost_map_.info.height = cost_map_width_;
    cost_map_.info.origin.position.x = 0.0;
    cost_map_.info.origin.position.y = -(cost_map_width_ * cost_map_res_) / 2.0;
    cost_map_.data.resize(cost_map_width_ * cost_map_width_, 0);
    
    // Initialize occupancy grid (내부 관리)
    occupancy_grid_ = Eigen::MatrixXi::Zero(grid_height_, grid_width_);
    
    // Load waypoints
    try {
        waypoints_ = load_waypoints(waypoint_path_);
        RCLCPP_INFO(this->get_logger(), "Loaded %ld waypoints", waypoints_.rows());
    } catch (const std::exception& e) {
        RCLCPP_ERROR(this->get_logger(), "Error loading waypoints file: %s", e.what());
    }
    
    // Setup TF2
    tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
    
    // Create publishers
    trajectory_pub_ = this->create_publisher<safe_path_msg::msg::SafePath>(
        trajectory_topic_, 10);
    
    if (visualize_) {
        cost_map_pub_ = this->create_publisher<nav_msgs::msg::OccupancyGrid>(
            cost_map_topic_, 10);
        marker_pub_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(
            marker_topic_, 10);
        
        // 디버깅용 occupancy grid publisher (선택사항)
        occupancy_pub_ = this->create_publisher<nav_msgs::msg::OccupancyGrid>(
            "/local_map", 10);
        
        // Publish initial waypoints
        publish_markers(waypoints_, Eigen::Vector3d(1.0, 0.0, 0.0), "waypoints");
    }
    
    // Create subscriber - LaserScan으로 변경
    scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
        scan_topic_, 10,
        std::bind(&MPPIController::laser_scan_callback, this, std::placeholders::_1));
    
    // Create timer (40 Hz)
    timer_ = this->create_wall_timer(
        std::chrono::milliseconds(25), // ~40 Hz
        std::bind(&MPPIController::trajectory_callback, this));
    
    RCLCPP_INFO(this->get_logger(), "MPPI node initialized with integrated obstacle detection");
}

void MPPIController::initialize_parameters() {
    // 기존 파라미터
    this->declare_parameter("visualize", true);
    this->declare_parameter("waypoint_path", "251025.csv");
    this->declare_parameter("vehicle_frame", "laser");
    this->declare_parameter("trajectory_topic", "/safe_trajectory");
    this->declare_parameter("cost_map_topic", "/cost_map");
    this->declare_parameter("marker_topic", "/markers");
    this->declare_parameter("scan_topic", "/scan");  // LaserScan 토픽
    this->declare_parameter("pose_topic", "/pf/pose/odom");
    
    this->declare_parameter("wheelbase", 0.33);
    this->declare_parameter("max_steer", 0.8378);
    this->declare_parameter("min_throttle", 0.75);
    this->declare_parameter("max_throttle", 1.0);
    
    this->declare_parameter("dt", 0.1);
    this->declare_parameter("num_trajectories", 500);
    this->declare_parameter("steps_trajectories", 30);
    this->declare_parameter("v_sigma", 0.05);
    this->declare_parameter("omega_sigma", 0.2);
    
    this->declare_parameter("cost_map_res", 0.05);
    this->declare_parameter("cost_map_width", 100);
    this->declare_parameter("raceline_dilation", 3);
    this->declare_parameter("heading_weight", 0.0);
    this->declare_parameter("raceline_weight", 1.0);
    this->declare_parameter("obstacle_weight", 1.5);
    
    // LaserScan → OccupancyGrid 파라미터 추가
    this->declare_parameter("grid_resolution", 0.05);
    this->declare_parameter("grid_width", 100);
    this->declare_parameter("grid_height", 100);
    this->declare_parameter("obstacle_dilation", 10);
    
    // Get parameter values
    visualize_ = this->get_parameter("visualize").as_bool();
    waypoint_path_ = this->get_parameter("waypoint_path").as_string();
    vehicle_frame_ = this->get_parameter("vehicle_frame").as_string();
    trajectory_topic_ = this->get_parameter("trajectory_topic").as_string();
    cost_map_topic_ = this->get_parameter("cost_map_topic").as_string();
    marker_topic_ = this->get_parameter("marker_topic").as_string();
    scan_topic_ = this->get_parameter("scan_topic").as_string();
    pose_topic_ = this->get_parameter("pose_topic").as_string();
    
    wheelbase_ = this->get_parameter("wheelbase").as_double();
    max_steer_ = this->get_parameter("max_steer").as_double();
    min_throttle_ = this->get_parameter("min_throttle").as_double();
    max_throttle_ = this->get_parameter("max_throttle").as_double();
    
    dt_ = this->get_parameter("dt").as_double();
    num_trajectories_ = this->get_parameter("num_trajectories").as_int();
    steps_trajectories_ = this->get_parameter("steps_trajectories").as_int();
    v_sigma_ = this->get_parameter("v_sigma").as_double();
    omega_sigma_ = this->get_parameter("omega_sigma").as_double();
    
    cost_map_res_ = this->get_parameter("cost_map_res").as_double();
    cost_map_width_ = this->get_parameter("cost_map_width").as_int();
    raceline_dilation_ = this->get_parameter("raceline_dilation").as_int();
    heading_weight_ = this->get_parameter("heading_weight").as_double();
    raceline_weight_ = this->get_parameter("raceline_weight").as_double();
    obstacle_weight_ = this->get_parameter("obstacle_weight").as_double();
    
    grid_resolution_ = this->get_parameter("grid_resolution").as_double();
    grid_width_ = this->get_parameter("grid_width").as_int();
    grid_height_ = this->get_parameter("grid_height").as_int();
    obstacle_dilation_ = this->get_parameter("obstacle_dilation").as_int();
}

Eigen::MatrixXd MPPIController::load_waypoints(const std::string& path) {
    // Get package share directory
    std::string package_path;
    try {
        package_path = ament_index_cpp::get_package_share_directory("f1tenth_mppi");
    } catch (const std::exception& e) {
        RCLCPP_ERROR(this->get_logger(), "Failed to get package directory: %s", e.what());
        throw;
    }
    
    // Construct full file path
    size_t install_pos = package_path.find("install");
    std::string base_path;
    if (install_pos != std::string::npos) {
        base_path = package_path.substr(0, install_pos);
    } else {
        base_path = package_path + "/../../";
    }
    std::string full_path = base_path + "src/ICRA2026-Paper/maps/" + path;
    
    RCLCPP_INFO(this->get_logger(), "Loading waypoints from: %s", full_path.c_str());
    
    std::ifstream file(full_path);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open waypoints file: " + full_path);
    }
    
    std::vector<Eigen::Vector4d> waypoints;
    std::string line;
    
    // Skip first 3 lines (header)
    for (int i = 0; i < 3; ++i) {
        if (!std::getline(file, line)) {
            throw std::runtime_error("Waypoints file has less than 3 header lines");
        }
    }
    
    // Read waypoints with semicolon delimiter
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string value;
        std::vector<double> row;
        
        // Parse line with semicolon delimiter
        while (std::getline(ss, value, ';')) {
            try {
                row.push_back(std::stod(value));
            } catch (const std::exception& e) {
                // Skip invalid values
                row.push_back(0.0);
            }
        }
        
        // Extract columns: x(index 1), y(index 2), psi(index 3), vx(index 5)
        if (row.size() >= 6) {
            Eigen::Vector4d waypoint;
            waypoint << row[1], row[2], row[3], row[5];
            waypoints.push_back(waypoint);
        }
    }
    
    file.close();
    
    if (waypoints.empty()) {
        throw std::runtime_error("No valid waypoints found");
    }
    
    Eigen::MatrixXd waypoints_matrix(waypoints.size(), 4);
    for (size_t i = 0; i < waypoints.size(); ++i) {
        waypoints_matrix.row(i) = waypoints[i];
    }
    
    return waypoints_matrix;
}

// ============================================================================
// LaserScan → OccupancyGrid 변환 (Python 코드를 C++로 변환)
// ============================================================================

Eigen::MatrixXi MPPIController::create_occupancy_grid_from_scan(
    const sensor_msgs::msg::LaserScan::SharedPtr scan_msg) {
    
    // Initialize occupancy grid
    Eigen::MatrixXi occupancy_grid = Eigen::MatrixXi::Zero(grid_height_, grid_width_);
    
    // Extract angles and ranges
    std::vector<double> angles;
    std::vector<double> ranges;
    
    for (size_t i = 0; i < scan_msg->ranges.size(); ++i) {
        double angle = scan_msg->angle_min + scan_msg->angle_increment * i;
        double range = scan_msg->ranges[i];
        
        // Filter valid ranges
        if (std::isfinite(range) && range >= scan_msg->range_min && range <= scan_msg->range_max) {
            angles.push_back(angle);
            ranges.push_back(range);
        }
    }
    
    // Convert polar to Cartesian coordinates (x: forward, y: left)
    for (size_t i = 0; i < ranges.size(); ++i) {
        double x_coord = ranges[i] * std::cos(angles[i]);
        double y_coord = ranges[i] * std::sin(angles[i]);
        
        // Convert to grid indices
        // Origin: x=0 (vehicle at left edge), y=-(height/2)*res (vehicle at center)
        int x_idx = static_cast<int>(x_coord / grid_resolution_);
        int y_idx = static_cast<int>(y_coord / grid_resolution_ + grid_height_ / 2.0);
        
        // Check bounds
        if (x_idx >= 0 && x_idx < grid_width_ && y_idx >= 0 && y_idx < grid_height_) {
            occupancy_grid(y_idx, x_idx) = 100;
        }
    }
    
    // Apply dilation using OpenCV
    if (obstacle_dilation_ > 0) {
        cv::Mat cv_grid(grid_height_, grid_width_, CV_8UC1);
        
        // Convert Eigen to cv::Mat
        for (int i = 0; i < grid_height_; ++i) {
            for (int j = 0; j < grid_width_; ++j) {
                cv_grid.at<uint8_t>(i, j) = static_cast<uint8_t>(occupancy_grid(i, j) > 0 ? 255 : 0);
            }
        }
        
        // Create dilation kernel
        cv::Mat kernel = cv::getStructuringElement(
            cv::MORPH_RECT, 
            cv::Size(obstacle_dilation_, obstacle_dilation_)
        );
        
        // Apply binary dilation
        cv::Mat dilated;
        cv::dilate(cv_grid, dilated, kernel);
        
        // Convert back to Eigen
        for (int i = 0; i < grid_height_; ++i) {
            for (int j = 0; j < grid_width_; ++j) {
                occupancy_grid(i, j) = dilated.at<uint8_t>(i, j) > 0 ? 100 : 0;
            }
        }
    }
    
    return occupancy_grid;
}

// ============================================================================
// LaserScan Callback (새로 추가됨)
// ============================================================================

void MPPIController::laser_scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg) {
    // LaserScan을 OccupancyGrid로 변환 (내부 처리)
    occupancy_grid_ = create_occupancy_grid_from_scan(msg);
    
    // 디버깅용: OccupancyGrid 발행 (선택사항)
    if (visualize_ && occupancy_pub_) {
        nav_msgs::msg::OccupancyGrid og_msg;
        og_msg.header.stamp = this->now();
        og_msg.header.frame_id = vehicle_frame_;
        og_msg.info.resolution = grid_resolution_;
        og_msg.info.width = grid_width_;
        og_msg.info.height = grid_height_;
        og_msg.info.origin.position.x = 0.0;
        og_msg.info.origin.position.y = -(grid_height_ / 2.0) * grid_resolution_;
        
        og_msg.data.resize(grid_width_ * grid_height_);
        for (int i = 0; i < grid_height_; ++i) {
            for (int j = 0; j < grid_width_; ++j) {
                og_msg.data[i * grid_width_ + j] = static_cast<int8_t>(occupancy_grid_(i, j));
            }
        }
        
        occupancy_pub_->publish(og_msg);
    }
}

// ============================================================================
// Trajectory Callback (기존 코드 유지)
// ============================================================================

void MPPIController::trajectory_callback() {
    auto t0 = this->now();
    
    // Check if we have occupancy grid data
    if (occupancy_grid_.sum() == 0) {
        return;
    }
    
    try {
        // occupancy_grid_는 이미 Eigen::MatrixXi 타입이므로 그대로 사용
        
        // Update cost map
        Eigen::MatrixXd cost_map = update_cost_map(occupancy_grid_);
        
        // Sample trajectories
        auto [trajectories, actions] = sample_trajectories(num_trajectories_, steps_trajectories_);
        
        // Evaluate trajectories
        int min_cost_idx = evaluate_trajectories(cost_map, trajectories, occupancy_grid_);
        
        // Prepare SafePath message
        auto safe_path = safe_path_msg::msg::SafePath();
        safe_path.header.stamp = this->now();
        
        if (min_cost_idx == -1) {
            safe_path.flag = false;
            safe_path.path = nav_msgs::msg::Path();
            trajectory_pub_->publish(safe_path);
            return;
        }
        
        // Transform to absolute coordinates
        geometry_msgs::msg::TransformStamped transform;
        try {
            transform = tf_buffer_->lookupTransform(
                "map", vehicle_frame_, tf2::TimePointZero, tf2::durationFromSec(0.1));
        } catch (const tf2::TransformException& ex) {
            RCLCPP_WARN(this->get_logger(), "TF lookup failed: %s", ex.what());
            return;
        }
        
        // Extract translation and rotation
        double tx = transform.transform.translation.x;
        double ty = transform.transform.translation.y;
        double qx = transform.transform.rotation.x;
        double qy = transform.transform.rotation.y;
        double qz = transform.transform.rotation.z;
        double qw = transform.transform.rotation.w;
        
        double yaw = std::atan2(2.0 * (qw * qz + qx * qy), 1.0 - 2.0 * (qy * qy + qz * qz));
        
        // Create rotation matrix and translation vector
        Eigen::Matrix2d R;
        R << std::cos(yaw), -std::sin(yaw),
             std::sin(yaw),  std::cos(yaw);
        Eigen::Vector2d T(tx, ty);
        
        // Transform best trajectory to absolute coordinates
        const auto& best_trajectory = trajectories[min_cost_idx];
        Eigen::MatrixXd best_trajectory_absolute(best_trajectory.rows(), 3);
        
        for (int i = 0; i < best_trajectory.rows(); ++i) {
            Eigen::Vector2d xy_relative(best_trajectory(i, 0), best_trajectory(i, 1));
            Eigen::Vector2d xy_absolute = R * xy_relative + T;
            double theta_absolute = best_trajectory(i, 2) + yaw;
            
            best_trajectory_absolute(i, 0) = xy_absolute(0);
            best_trajectory_absolute(i, 1) = xy_absolute(1);
            best_trajectory_absolute(i, 2) = theta_absolute;
        }
        
        // Update mean control
        u_mean_(0) = actions(min_cost_idx, 0);
        
        // Populate SafePath message
        safe_path.flag = true;
        safe_path.path.header.frame_id = vehicle_frame_;
        safe_path.path.header.stamp = this->now();
        
        for (int i = 0; i < best_trajectory_absolute.rows(); ++i) {
            geometry_msgs::msg::PoseStamped pose;
            pose.pose.position.x = best_trajectory_absolute(i, 0);
            pose.pose.position.y = best_trajectory_absolute(i, 1);
            pose.pose.orientation.w = best_trajectory_absolute(i, 2);
            safe_path.path.poses.push_back(pose);
        }
        
        trajectory_pub_->publish(safe_path);
        
        // Log performance (주석 처리됨)
        // auto t1 = this->now();
        // double duration_s = (t1 - t0).seconds();
        // double iter_hz = duration_s > 0.0 ? 1.0 / duration_s : 0.0;
        
        // if (static_cast<int>(duration_s * 10) % 10 == 0) {
        //     RCLCPP_INFO(this->get_logger(), "Publish trajectory / iters_per_sec: %.3f Hz", iter_hz);
        // }
        
    } catch (const std::exception& e) {
        RCLCPP_WARN(this->get_logger(), "Error in trajectory callback: %s", e.what());
    }
}

Eigen::MatrixXd MPPIController::update_cost_map(const Eigen::MatrixXi& occupancy_grid) {
    // Transform waypoints to vehicle frame
    Eigen::MatrixXd waypoints_vehicle(waypoints_.rows(), 2);
    
    for (int i = 0; i < waypoints_.rows(); ++i) {
        geometry_msgs::msg::TransformStamped transform;
        try {
            transform = tf_buffer_->lookupTransform(
                vehicle_frame_, "map",
                tf2::TimePointZero);
        } catch (tf2::TransformException& ex) {
            RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 2000,
                                "Could not get transform for waypoints: %s", ex.what());
            return Eigen::MatrixXd::Zero(cost_map_width_, cost_map_width_);
        }
        
        geometry_msgs::msg::PointStamped point_in, point_out;
        point_in.header.frame_id = "map";
        point_in.point.x = waypoints_(i, 0);
        point_in.point.y = waypoints_(i, 1);
        
        tf2::doTransform(point_in, point_out, transform);
        
        waypoints_vehicle(i, 0) = point_out.point.x;
        waypoints_vehicle(i, 1) = point_out.point.y;
    }
    
    // Create cost map
    Eigen::MatrixXd cost_map = Eigen::MatrixXd::Zero(cost_map_width_, cost_map_width_);
    cv::Mat raceline_grid = cv::Mat::zeros(cost_map_width_, cost_map_width_, CV_8UC1);
    
    // Draw raceline
    for (int i = 0; i < waypoints_vehicle.rows(); ++i) {
        double x_pixel = waypoints_vehicle(i, 0) / cost_map_res_;
        double y_pixel = waypoints_vehicle(i, 1) / cost_map_res_ + cost_map_width_ / 2.0;
        
        int x_idx = static_cast<int>(std::clamp(x_pixel, 0.0, 
                                     static_cast<double>(cost_map_width_ - 1)));
        int y_idx = static_cast<int>(std::clamp(y_pixel, 0.0, 
                                     static_cast<double>(cost_map_width_ - 1)));
        
        raceline_grid.at<uint8_t>(y_idx, x_idx) = 255;
    }
    
    // Dilate raceline
    if (raceline_dilation_ > 0) {
        cv::Mat kernel = cv::getStructuringElement(
            cv::MORPH_RECT,
            cv::Size(raceline_dilation_ * 2 + 1, raceline_dilation_ * 2 + 1)
        );
        cv::dilate(raceline_grid, raceline_grid, kernel);
    }
    
    // Compute distance transform
    cv::Mat dist_transform;
    cv::distanceTransform(255 - raceline_grid, dist_transform, cv::DIST_L2, 3);
    
    // Normalize distance transform
    double min_val, max_val;
    cv::minMaxLoc(dist_transform, &min_val, &max_val);
    if (max_val > 0) {
        dist_transform = dist_transform / max_val * 100.0;
    }
    
    // Convert to Eigen and apply weights
    for (int i = 0; i < cost_map_width_; ++i) {
        for (int j = 0; j < cost_map_width_; ++j) {
            double raceline_cost = dist_transform.at<float>(i, j) * raceline_weight_;
            double obstacle_cost = (occupancy_grid(i, j) > 0) ? 100.0 * obstacle_weight_ : 0.0;
            cost_map(i, j) = raceline_cost + obstacle_cost;
        }
    }
    
    // Publish cost map for visualization
    if (visualize_) {
        for (int i = 0; i < cost_map.rows(); ++i) {
            for (int j = 0; j < cost_map.cols(); ++j) {
                cost_map_.data[i * cost_map.cols() + j] = static_cast<int8_t>(cost_map(i, j));
            }
        }
        cost_map_.header.stamp = this->now();
        cost_map_pub_->publish(cost_map_);
    }
    
    return cost_map / 100.0; // Normalize to 0-1
}

std::pair<std::vector<Eigen::MatrixXd>, Eigen::MatrixXd> 
MPPIController::sample_trajectories(int num_trajectories, int steps_trajectories) {
    // Sample control values
    Eigen::MatrixXd v(num_trajectories, steps_trajectories - 1);
    Eigen::MatrixXd omega(num_trajectories, steps_trajectories - 1);
    
    for (int i = 0; i < num_trajectories; ++i) {
        double v_sample = max_throttle_ + dist_(gen_) * v_sigma_;
        double omega_sample = u_mean_(1) + dist_(gen_) * omega_sigma_;
        
        for (int j = 0; j < steps_trajectories - 1; ++j) {
            v(i, j) = v_sample;
            omega(i, j) = omega_sample;
        }
    }
    
    // Clip control values
    v = v.cwiseMax(min_throttle_).cwiseMin(max_throttle_);
    omega = omega.cwiseMax(-max_steer_).cwiseMin(max_steer_);
    
    // Combine into actions matrix
    Eigen::MatrixXd actions(num_trajectories, (steps_trajectories - 1) * 2);
    actions << v, omega;
    
    // Sample trajectories
    std::vector<Eigen::MatrixXd> trajectories(num_trajectories);
    for (int i = 0; i < num_trajectories; ++i) {
        trajectories[i] = Eigen::MatrixXd::Zero(steps_trajectories, 3);
        
        for (int j = 0; j < steps_trajectories - 1; ++j) {
            Eigen::Vector2d action(v(i, j), omega(i, j));
            trajectories[i].row(j + 1) = model_->predict_euler(
                trajectories[i].row(j).transpose(), action).transpose();
        }
    }
    
    // Publish subset of trajectories for visualization
    if (visualize_) {
        std::vector<Eigen::MatrixXd> subset;
        for (int i = 0; i < std::min(5, num_trajectories); ++i) {
            subset.push_back(trajectories[i]);
        }
        publish_trajectories(subset);
    }
    
    return {trajectories, actions};
}

int MPPIController::evaluate_trajectories(const Eigen::MatrixXd& cost_map,
                                          const std::vector<Eigen::MatrixXd>& trajectories,
                                          const Eigen::MatrixXi& occupancy_grid) {
    int num_trajectories = trajectories.size();
    int steps = trajectories[0].rows();
    
    Eigen::VectorXd traj_scores(num_trajectories);
    traj_scores.setZero();
    
    std::vector<bool> bad_trajs(num_trajectories, false);
    
    for (int i = 0; i < num_trajectories; ++i) {
        double score = 0.0;
        
        for (int j = 0; j < steps; ++j) {
            // Convert to pixel coordinates
            double x_pixel = trajectories[i](j, 0) / cost_map_.info.resolution;
            double y_pixel = trajectories[i](j, 1) / cost_map_.info.resolution + 
                           cost_map_.info.height / 2.0;
            
            int x_idx = static_cast<int>(std::clamp(x_pixel, 0.0, 
                                         static_cast<double>(cost_map_.info.width - 1)));
            int y_idx = static_cast<int>(std::clamp(y_pixel, 0.0, 
                                         static_cast<double>(cost_map_.info.height - 1)));
            
            // Check for obstacles
            if (occupancy_grid(y_idx, x_idx) > 0) {
                bad_trajs[i] = true;
                break;
            }
            
            score += cost_map(y_idx, x_idx);
        }
        
        traj_scores(i) = score;
    }
    
    // Normalize scores
    double max_score = traj_scores.maxCoeff();
    if (max_score > 0) {
        traj_scores /= max_score;
    }
    
    // Set bad trajectories to infinity
    for (int i = 0; i < num_trajectories; ++i) {
        if (bad_trajs[i]) {
            traj_scores(i) = std::numeric_limits<double>::infinity();
        }
    }
    
    // Find minimum cost trajectory
    int min_cost_idx = -1;
    double min_cost = std::numeric_limits<double>::infinity();
    
    for (int i = 0; i < num_trajectories; ++i) {
        if (traj_scores(i) < min_cost) {
            min_cost = traj_scores(i);
            min_cost_idx = i;
        }
    }
    
    // Publish best trajectory
    if (min_cost_idx >= 0 && visualize_) {
        std::vector<Eigen::MatrixXd> best_traj = {trajectories[min_cost_idx]};
        publish_trajectories(best_traj, Eigen::Vector3d(1.0, 0.0, 0.0));
    }
    
    return min_cost_idx;
}

void MPPIController::publish_trajectories(const std::vector<Eigen::MatrixXd>& trajectories,
                                          const Eigen::Vector3d& color) {
    if (!visualize_) return;
    
    auto marker_array = visualization_msgs::msg::MarkerArray();
    
    for (size_t j = 0; j < trajectories.size(); ++j) {
        const auto& traj = trajectories[j];
        for (int i = 0; i < traj.rows() - 1; ++i) {
            auto marker = visualization_msgs::msg::Marker();
            marker.header.frame_id = vehicle_frame_;
            marker.id = j * traj.rows() + i;
            marker.header.stamp = this->now();
            marker.type = visualization_msgs::msg::Marker::LINE_LIST;
            marker.action = visualization_msgs::msg::Marker::ADD;
            marker.color.r = color(0);
            marker.color.g = color(1);
            marker.color.b = color(2);
            marker.color.a = 1.0;
            marker.scale.x = 0.01;
            
            geometry_msgs::msg::Point p1, p2;
            p1.x = traj(i, 0);
            p1.y = traj(i, 1);
            p2.x = traj(i + 1, 0);
            p2.y = traj(i + 1, 1);
            
            marker.points.push_back(p1);
            marker.points.push_back(p2);
            marker_array.markers.push_back(marker);
        }
    }
    
    publish_markers(waypoints_, Eigen::Vector3d(1.0, 0.0, 0.0), "waypoints");
    marker_pub_->publish(marker_array);
}

void MPPIController::publish_markers(const Eigen::MatrixXd& points,
                                     const Eigen::Vector3d& color,
                                     const std::string& ns) {
    if (!visualize_) return;
    
    auto marker_array = visualization_msgs::msg::MarkerArray();
    
    for (int i = 0; i < points.rows(); ++i) {
        auto marker = visualization_msgs::msg::Marker();
        marker.ns = ns;
        marker.header.frame_id = "map";
        marker.id = i + 1;
        marker.header.stamp = this->now();
        marker.type = visualization_msgs::msg::Marker::SPHERE;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = points(i, 0);
        marker.pose.position.y = points(i, 1);
        marker.color.r = color(0);
        marker.color.g = color(1);
        marker.color.b = color(2);
        marker.color.a = 1.0;
        marker.scale.x = 0.1;
        marker.scale.y = 0.1;
        marker.scale.z = 0.1;
        
        marker_array.markers.push_back(marker);
    }
    
    marker_pub_->publish(marker_array);
}

// ============================================================================
// Main Function
// ============================================================================

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<MPPIController>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}