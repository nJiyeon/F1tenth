#ifndef MPPI_CONTROLLER_HPP
#define MPPI_CONTROLLER_HPP

#include <memory>
#include <vector>
#include <string>
#include <random>

#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <nav_msgs/msg/path.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <visualization_msgs/msg/marker.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <ament_index_cpp/get_package_share_directory.hpp>

#include <Eigen/Dense>
#include <opencv2/opencv.hpp>

// SafePath 커스텀 메시지 (이 부분은 실제 메시지 정의에 맞게 수정 필요)
#include "safe_path_msg/msg/safe_path.hpp"

using namespace std::chrono_literals;

class KinematicBicycleModel {
public:
    KinematicBicycleModel(double wheelbase, double min_throttle, double max_throttle,
                          double max_steer, double dt);
    
    Eigen::Vector3d predict_euler(const Eigen::Vector3d& state, const Eigen::Vector2d& action);
    
private:
    double wheelbase_;
    double min_throttle_;
    double max_throttle_;
    double max_steer_;
    double dt_;
};

class MPPIController : public rclcpp::Node {
public:
    MPPIController();
    ~MPPIController() = default;

private:
    // 초기화 함수
    void initialize_parameters();
    Eigen::MatrixXd load_waypoints(const std::string& path);
    
    // 콜백 함수
    void occupancy_callback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg);
    void trajectory_callback();
    
    // MPPI 알고리즘 함수
    Eigen::MatrixXd update_cost_map(const Eigen::MatrixXi& occupancy_grid);
    std::pair<std::vector<Eigen::MatrixXd>, Eigen::MatrixXd> 
        sample_trajectories(int num_trajectories, int steps_trajectories);
    int evaluate_trajectories(const Eigen::MatrixXd& cost_map,
                             const std::vector<Eigen::MatrixXd>& trajectories,
                             const Eigen::MatrixXi& occupancy_grid);
    
    // 시각화 함수
    void publish_trajectories(const std::vector<Eigen::MatrixXd>& trajectories,
                             const Eigen::Vector3d& color = Eigen::Vector3d(0.0, 0.0, 1.0));
    void publish_markers(const Eigen::MatrixXd& points,
                        const Eigen::Vector3d& color = Eigen::Vector3d(1.0, 0.0, 0.0),
                        const std::string& ns = "");
    
    // ROS2 Publishers
    rclcpp::Publisher<safe_path_msg::msg::SafePath>::SharedPtr trajectory_pub_;
    rclcpp::Publisher<nav_msgs::msg::OccupancyGrid>::SharedPtr cost_map_pub_;
    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr marker_pub_;
    
    // ROS2 Subscribers
    rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr occupancy_sub_;
    
    // Timer
    rclcpp::TimerBase::SharedPtr timer_;
    
    // TF2
    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    
    // 파라미터
    bool visualize_;
    std::string waypoint_path_;
    std::string vehicle_frame_;
    std::string trajectory_topic_;
    std::string cost_map_topic_;
    std::string marker_topic_;
    std::string occupancy_topic_;
    std::string pose_topic_;
    
    double wheelbase_;
    double max_steer_;
    double min_throttle_;
    double max_throttle_;
    
    double dt_;
    int num_trajectories_;
    int steps_trajectories_;
    double v_sigma_;
    double omega_sigma_;
    
    double cost_map_res_;
    int cost_map_width_;
    int raceline_dilation_;
    double heading_weight_;
    double raceline_weight_;
    double obstacle_weight_;
    
    // 내부 상태 변수
    Eigen::Vector2d u_mean_;
    Eigen::MatrixXd waypoints_;
    nav_msgs::msg::OccupancyGrid::SharedPtr occupancy_grid_;
    nav_msgs::msg::OccupancyGrid cost_map_;
    
    // Dynamics Model
    std::unique_ptr<KinematicBicycleModel> model_;
    
    // Random number generator
    std::mt19937 gen_;
    std::normal_distribution<double> dist_;
};

#endif // MPPI_CONTROLLER_HPP
